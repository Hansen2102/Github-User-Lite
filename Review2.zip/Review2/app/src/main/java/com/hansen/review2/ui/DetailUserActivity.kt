package com.hansen.review2.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.hansen.review2.R
import com.hansen.review2.data.adapter.SectionPagerAdapter
import com.hansen.review2.databinding.ActivityDetailUserBinding

class DetailUserActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailUserBinding
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val login = intent.getStringExtra("login")
        if (login != null) {
            viewModel.findDetailUser(login)
        } else {
            Log.e(TAG, "Username is null")
        }


        viewModel.detailUser.observe(this) { detailUserResponse ->
            binding.tvName.text = detailUserResponse.name
            binding.tvUsername.text = detailUserResponse.login
            binding.tvFollowersValue.text = detailUserResponse.followers.toString()
            binding.tvFollowingValue.text = detailUserResponse.following.toString()

            Glide.with(this@DetailUserActivity)
                .load(detailUserResponse.avatarUrl)
                .into(binding.imgAvatar)

            val sectionAdapter = SectionPagerAdapter(this@DetailUserActivity, detailUserResponse.login.toString())
            val viewPager: ViewPager2 = findViewById(R.id.view_pager)
            viewPager.adapter = sectionAdapter

            val tabs: TabLayout = findViewById(R.id.tabs)

            TabLayoutMediator(tabs, viewPager) { tab, position ->
                tab.text = resources.getString(TAB_TITLES[position])
            }.attach()
            supportActionBar?.elevation = 0f

        }
        viewModel.isLoading.observe(this) {
            showLoading(it)
        }
    }
    companion object {
        private const val TAG = "DetailUserActivity"
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.follower,
            R.string.following
        )
    }
    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}
